let first = String.uppercase_ascii (String.sub w 0 1) in
      let rest  = String.lowercase_ascii (String.sub w 1 (String.length w - 1)) in
