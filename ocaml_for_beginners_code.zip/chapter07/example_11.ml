let rec fact n =
  if n <= 1 then 1
