let full_name first last =
  let trimmed_first = String.trim first in
  let trimmed_last  = String.trim last in
  let combined = trimmed_first ^ " " ^ trimmed_last in
