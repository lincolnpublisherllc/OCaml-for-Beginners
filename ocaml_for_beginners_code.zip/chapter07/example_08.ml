let () =
  let q, r = div_mod 17 5 in
  Printf.printf "q=%d r=%d\n" q r
