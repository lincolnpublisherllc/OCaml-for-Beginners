let add a b = a + b
let greet name = "Hello, " ^ name
