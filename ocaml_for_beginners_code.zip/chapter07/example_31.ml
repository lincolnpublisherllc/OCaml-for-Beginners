let () =
  let nums = [1;2;3;4;5;6] in
  let doubled = List.map (fun x -> x * 2) nums in
  let evens   = List.filter (fun x -> x mod 2 = 0) doubled in
  List.iter (fun x -> Printf.printf "%d " x) evens;
  print_endline ""
