let is_vowel c =
  match Char.lowercase_ascii c with
