let acc' = if is_vowel s.[i] then acc + 1 else acc in
