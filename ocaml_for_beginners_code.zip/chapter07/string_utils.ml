(* string_utils.ml *)
let title_case s =
  let words = String.split_on_char ' ' s in
  let cap w =
    if String.length w = 0 then w
