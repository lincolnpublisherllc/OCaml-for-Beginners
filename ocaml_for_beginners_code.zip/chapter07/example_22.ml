let average a b =
