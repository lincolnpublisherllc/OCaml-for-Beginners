let () =
  let a = 3 in
  let b = 4 in
  let c = a * b in
  Printf.printf "Area=%d\n" c
