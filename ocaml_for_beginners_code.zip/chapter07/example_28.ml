let count_vowels s =
  let n = String.length s in
  let rec loop i acc =
    if i = n then acc
