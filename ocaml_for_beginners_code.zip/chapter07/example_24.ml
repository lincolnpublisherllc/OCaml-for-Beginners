String.concat " " (List.map cap words)
