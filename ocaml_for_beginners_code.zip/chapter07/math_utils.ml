(* math_utils.ml *)
let clamp low high x =
  if x < low then low else if x > high then high else x
