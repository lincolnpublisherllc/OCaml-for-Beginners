let only_even lst =
  List.filter (fun n -> n mod 2 = 0) lst
