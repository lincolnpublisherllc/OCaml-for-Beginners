let double_all lst =
  List.map (fun x -> x * 2) lst
