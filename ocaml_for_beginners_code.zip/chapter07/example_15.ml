let apply_twice f x =
