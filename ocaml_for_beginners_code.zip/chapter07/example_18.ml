let () =
  let double = (fun x -> x * 2) in
  Printf.printf "%d\n" (double 7)
