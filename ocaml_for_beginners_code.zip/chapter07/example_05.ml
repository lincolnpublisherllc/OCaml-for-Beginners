let () = say_hello ()
