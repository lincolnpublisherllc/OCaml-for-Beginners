let () =
  let result = double_all [1;2;3] in
  List.iter (fun x -> Printf.printf "%d " x) result;
  print_endline ""
