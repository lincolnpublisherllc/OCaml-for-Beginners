let () =
  print_endline (safe_div 10 2);  (* 5 *)
  print_endline (safe_div 7 0)    (* undefined *)
