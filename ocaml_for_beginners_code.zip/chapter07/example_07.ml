let div_mod a b =
  (a / b, a mod b)   (* returns a pair *)
