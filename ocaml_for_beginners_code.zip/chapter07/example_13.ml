let price_with_tax price rate =
  let tax = price *. rate in
  let total = price +. tax in
