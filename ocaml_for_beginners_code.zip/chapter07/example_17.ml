let () =
  Printf.printf "%d\n" (apply_twice inc 10)  (* 12 *)
