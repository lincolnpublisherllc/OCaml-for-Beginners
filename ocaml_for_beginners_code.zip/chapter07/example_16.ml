let inc n = n + 1
