(* bin/main.ml *)
let () =
  Printf.printf "Clamp: %d\n" (Math_utils.clamp 0 10 14);
  print_endline (String_utils.title_case "hello from ocaml")
