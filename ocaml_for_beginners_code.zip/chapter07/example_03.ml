let () =
  Printf.printf "%d\n" (add 3 4);
  print_endline (greet "Ada")
