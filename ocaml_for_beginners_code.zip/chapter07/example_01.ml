let name param1 param2 = 
  (* body that computes a value *)
