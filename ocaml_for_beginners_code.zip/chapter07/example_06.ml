let area_of_rectangle width height =
  width *. height   (* float result *)
let () =
  Printf.printf "Area = %.1f\n" (area_of_rectangle 4.0 3.5)
