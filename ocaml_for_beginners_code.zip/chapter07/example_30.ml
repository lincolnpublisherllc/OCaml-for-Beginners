let () = Printf.printf "vowels=%d\n" (count_vowels "ocaml")
