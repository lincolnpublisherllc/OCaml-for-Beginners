let () = Printf.printf "%d\n" (sum_to 5)  (* 15 *)
