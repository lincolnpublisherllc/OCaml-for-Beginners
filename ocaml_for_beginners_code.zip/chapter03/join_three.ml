(* join_three.ml *)
let () =
  print_endline "Word 1:";
  let w1 = read_line () in
  print_endline "Word 2:";
  let w2 = read_line () in
  print_endline "Word 3:";
  let w3 = read_line () in
  let sentence = String.concat " - " [w1; w2; w3] in
  Printf.printf "Combined: %s\n" sentence
