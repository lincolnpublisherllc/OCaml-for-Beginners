let () =
  let a = 1 in
  let b = 2 in
  Printf.printf "%d\n" (a + b)
