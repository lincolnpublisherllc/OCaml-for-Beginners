(* shout.ml *)
let () =
  print_endline "Say something:";
  let msg = read_line () in
  let upper = String.uppercase_ascii msg in
  Printf.printf "You said: %s\n" upper
