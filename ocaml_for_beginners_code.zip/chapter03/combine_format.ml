Printf.printf lets you format numbers and strings in one call.
(* combine_format.ml *)
let () =
  print_endline "Enter item name:";
  let item = read_line () in
  print_endline "Enter quantity:";
  let qty_str = read_line () in
  (* Convert a string to an int. This will raise if input is not a number. *)
  let qty = int_of_string qty_str in
  Printf.printf "You ordered %d x %s\n" qty item
