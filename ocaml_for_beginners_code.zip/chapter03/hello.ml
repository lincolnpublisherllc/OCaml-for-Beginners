(* hello.ml *)
let () =
  print_endline "Hello, World!"
