read_line returns a string that does not include the trailing newline.
