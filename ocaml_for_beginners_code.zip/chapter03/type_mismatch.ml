(* type_mismatch.ml *)
let () =
  let x = 10 in
  (* This is wrong on purpose. ^ is string concatenation, not addition. *)
  print_endline ("Result: " ^ (x + 1))
