(* hello_comment.ml *)
let () =
  (* Greet the user *)
  print_endline "Hello again";
