(* Blank lines are fine, use them to separate steps *)
  print_endline "This is cleaner to read"
