let () = ... defines a simple entry point.
print_endline prints a string followed by a newline.
