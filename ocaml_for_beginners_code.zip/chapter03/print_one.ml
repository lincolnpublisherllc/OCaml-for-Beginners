(* print_one.ml *)
let () =
  print_endline "Welcome to OCaml basics"
