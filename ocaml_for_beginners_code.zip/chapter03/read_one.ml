(* read_one.ml *)
let () =
  print_endline "What is your name?";
  let name = read_line () in
  print_endline ("Hello, " ^ name ^ "!")
