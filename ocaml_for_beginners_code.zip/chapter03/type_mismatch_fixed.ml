(* type_mismatch_fixed.ml *)
let () =
  let x = 10 in
  Printf.printf "Result: %d\n" (x + 1)
