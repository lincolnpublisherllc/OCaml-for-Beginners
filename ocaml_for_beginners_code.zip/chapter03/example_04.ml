Block comment: (* like this *)
