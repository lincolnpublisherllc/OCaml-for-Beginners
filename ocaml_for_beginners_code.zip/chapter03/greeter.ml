(* greeter.ml *)
let () =
  print_endline "Your first name?";
  let first = read_line () in
  print_endline "Your last name?";
  let last = read_line () in
  Printf.printf "Nice to meet you, %s %s.\n" first last
