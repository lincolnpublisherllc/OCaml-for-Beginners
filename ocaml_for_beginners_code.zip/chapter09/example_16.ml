let second lst =
  match lst with
