(* branch_types.ml *)
let describe n =
  if n > 0 then "positive"
  else 0  (* wrong: string vs int *)
