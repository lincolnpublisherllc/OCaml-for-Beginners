Printf.printf "[debug] bad int: %S\n" s;
