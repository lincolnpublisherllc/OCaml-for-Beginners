# let rec sum_to n = if n <= 0 then 0 else n + sum_to (n - 1);;
val sum_to : int -> int = <fun>
