(* only_two.ml *)
let second lst =
  match lst with
