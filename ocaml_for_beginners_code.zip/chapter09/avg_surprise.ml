(* avg_surprise.ml *)
let avg a b = (a + b) / 2         (* truncates *)
