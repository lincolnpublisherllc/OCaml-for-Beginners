(* format_mismatch.ml *)
let report name score =
  Printf.sprintf "%s scored %.1f" name score  (* expects float *)
