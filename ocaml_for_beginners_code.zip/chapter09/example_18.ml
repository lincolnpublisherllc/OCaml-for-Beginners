let sum a =
  let total = ref 0 in
  for i = 0 to Array.length a - 1 do
