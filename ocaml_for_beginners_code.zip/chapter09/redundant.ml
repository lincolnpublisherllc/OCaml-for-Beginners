(* redundant.ml *)
let to_bool n =
  match n with
