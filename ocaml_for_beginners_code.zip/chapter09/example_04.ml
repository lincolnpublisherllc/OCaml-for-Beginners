| 0 -> false    (* never reached *)
