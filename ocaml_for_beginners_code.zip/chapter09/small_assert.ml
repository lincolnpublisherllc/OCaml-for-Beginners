(* small_assert.ml *)
let mean a b =
  assert (b <> 0.0);            (* raises if false *)
