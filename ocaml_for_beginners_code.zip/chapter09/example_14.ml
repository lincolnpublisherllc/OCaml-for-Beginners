let () =
  print_endline (report "Ada" 10.0)
