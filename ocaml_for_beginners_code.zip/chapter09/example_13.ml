let () =
  print_endline (report "Ada" 10)  (* wrong: 10 is int *)
