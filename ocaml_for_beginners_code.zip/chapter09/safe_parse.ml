(* safe_parse.ml *)
let parse_int s =
