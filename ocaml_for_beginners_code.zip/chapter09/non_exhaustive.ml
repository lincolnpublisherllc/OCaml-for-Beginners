(* non_exhaustive.ml *)
let day_name n =
  match n with
