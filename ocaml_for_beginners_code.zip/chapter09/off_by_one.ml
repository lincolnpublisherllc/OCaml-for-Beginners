(* off_by_one.ml *)
let sum a =
  let total = ref 0 in
  for i = 0 to Array.length a do       (* wrong upper bound *)
