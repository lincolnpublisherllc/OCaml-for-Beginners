let explain a b =
  let msg = Printf.sprintf "[debug] a=%d b=%d" a b in
  print_endline msg;
