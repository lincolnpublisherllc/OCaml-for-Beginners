let describe n =
  if n > 0 then "positive"
