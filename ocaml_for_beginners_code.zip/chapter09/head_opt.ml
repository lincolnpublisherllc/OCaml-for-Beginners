(* head_opt.ml *)
let head_opt lst =
  match lst with
