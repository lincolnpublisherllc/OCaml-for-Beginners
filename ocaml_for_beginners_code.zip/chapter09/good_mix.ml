(* good_mix.ml *)
let () =
  let a = 3 in
  let b = 2.0 in
  Printf.printf "sum = %.1f\n" (float_of_int a +. b)
