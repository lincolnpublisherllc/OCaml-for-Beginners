(* debug_steps.ml *)
let total_cost price count =
  Printf.printf "[debug] price=%.2f count=%d\n" price count;
  let subtotal = price *. float_of_int count in
  Printf.printf "[debug] subtotal=%.2f\n" subtotal;
  let tax = subtotal *. 0.075 in
  let total = subtotal +. tax in
