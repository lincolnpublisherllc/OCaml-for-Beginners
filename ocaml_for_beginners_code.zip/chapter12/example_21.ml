let () =
  let p = { name = "Ada"; age = 36 } in
  let j = person_to_json p in
  let s = Yojson.Basic.to_string j in
  Printf.printf "json=%s\n" s;
  match person_of_json (Yojson.Basic.from_string s) with
