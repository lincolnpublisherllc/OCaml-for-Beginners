(* lib/math_utils.mli *)
val clamp : int -> int -> int -> int
val average : int -> int -> float
(* lib/math_utils.ml *)
let clamp low high x =
  if x < low then low else if x > high then high else x
