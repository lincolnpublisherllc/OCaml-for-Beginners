let map r f =
  match r with
