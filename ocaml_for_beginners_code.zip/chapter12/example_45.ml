let ic = open_in "in.txt" in
