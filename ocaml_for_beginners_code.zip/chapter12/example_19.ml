let find s =
        match List.assoc_opt s fields with
