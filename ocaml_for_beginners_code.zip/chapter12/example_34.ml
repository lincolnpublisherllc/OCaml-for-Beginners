(* int *)    +  -  *  /  mod
(* float *)  +. -. *. /.    (** pow **)  (**)
