let parse_nonempty s =
  if String.trim s = "" then Error Empty else Ok s
