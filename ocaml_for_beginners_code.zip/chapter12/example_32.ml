let abs n = if n < 0 then -n else n
