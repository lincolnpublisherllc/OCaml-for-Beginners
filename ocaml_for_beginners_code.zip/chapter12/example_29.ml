match person_of_json (Yojson.Basic.from_string line) with
