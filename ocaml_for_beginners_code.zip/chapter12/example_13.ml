let save_items filename items =
  let oc = open_out filename in
  List.iter (fun (name, qty) ->
