let load_items filename =
  let parse line =
    match String.split_on_char ',' line with
