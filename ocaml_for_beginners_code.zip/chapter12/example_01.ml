type shape = Circle of float | Rect of float * float
