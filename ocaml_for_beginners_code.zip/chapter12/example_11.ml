let () =
  Printf.printf "Clamp: %d\n" (My_lib.Math_utils.clamp 0 10 14);
  Printf.printf "Avg: %.1f\n" (My_lib.Math_utils.average 3 5)
