let oc = open_out "out.txt" in
