let show_result r =
  match r with
