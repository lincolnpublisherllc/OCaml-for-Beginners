while true do print_endline (input_line ic) done
with End_of_file -> close_in ic
