let read_lines filename =
  let ic = open_in filename in
  let rec loop acc =
    match input_line ic with
