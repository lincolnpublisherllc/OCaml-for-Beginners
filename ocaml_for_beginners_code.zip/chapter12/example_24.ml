let parse_int s =
  match int_of_string_opt s with
