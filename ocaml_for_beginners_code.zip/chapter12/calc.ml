(* lib/calc.ml *)
let mean a b = (a +. b) /. 2.0
let clamp01 x = if x < 0.0 then 0.0 else if x > 1.0 then 1.0 else x
