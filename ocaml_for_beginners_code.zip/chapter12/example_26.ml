let parse_count s =
