type person = { name : string; age : int }
