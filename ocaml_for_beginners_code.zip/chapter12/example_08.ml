let bind r f =
  match r with
