Printf.printf "%d %f %s %b\n" 3 2.5 "ok" true
