type contact = { name : string; email : string; phone : string }
