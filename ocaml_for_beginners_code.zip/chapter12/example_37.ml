let xs = [1;2;3]
1 :: xs           (* cons *)
xs @ [4;5]        (* append *)
List.map (fun x -> x * 2) xs
List.filter (fun x -> x mod 2 = 0) xs
List.fold_left ( + ) 0 xs
