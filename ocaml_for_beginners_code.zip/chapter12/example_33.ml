let day n =
  match n with
