let load_people filename =
