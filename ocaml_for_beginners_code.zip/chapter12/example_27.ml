(* lib/calc.mli *)
val mean : float -> float -> float
val clamp01 : float -> float
