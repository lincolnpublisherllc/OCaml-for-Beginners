let x = 42
let add a b = a + b
let () = print_endline "hello"
