Array.length a
Array.map (( * ) 2) a
