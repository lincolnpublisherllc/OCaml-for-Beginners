let head_opt = function
