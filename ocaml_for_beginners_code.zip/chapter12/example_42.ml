let r = ref 0 in r := !r + 1
