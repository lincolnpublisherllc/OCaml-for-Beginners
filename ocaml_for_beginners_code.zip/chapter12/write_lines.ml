(* write_lines.ml *)
let write_lines filename lines =
  let oc = open_out filename in
  List.iter (fun s -> output_string oc s; output_char oc '\n') lines;
