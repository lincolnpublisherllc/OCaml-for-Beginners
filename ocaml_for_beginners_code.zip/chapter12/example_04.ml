let default d = function Some x -> x | None -> d
let map_opt f = function Some x -> Some (f x) | None -> None
