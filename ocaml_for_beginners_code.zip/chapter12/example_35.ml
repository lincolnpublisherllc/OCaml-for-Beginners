String.length s
String.uppercase_ascii s
