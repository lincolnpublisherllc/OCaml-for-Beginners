type parse_err = Empty | NotAnInt of string
