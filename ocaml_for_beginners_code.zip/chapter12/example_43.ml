for i = 0 to 9 do Printf.printf "%d " i done
while cond do ... done
