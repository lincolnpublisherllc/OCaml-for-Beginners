(* find_by_id : int -> task list -> task option *)
let find_by_id id tasks =
  List.find_opt (fun t -> t.id = id) tasks
