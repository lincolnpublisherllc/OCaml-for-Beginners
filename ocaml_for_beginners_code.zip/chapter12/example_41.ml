type err = DivideByZero
let div a b = if b = 0 then Error DivideByZero else Ok (a / b)
