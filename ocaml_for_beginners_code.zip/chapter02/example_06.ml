let () =
  let a = 8 and b = 3 in
  Printf.printf "add=%d sub=%d mul=%d div=%.2f\n"
