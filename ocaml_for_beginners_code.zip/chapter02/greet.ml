(* greet.ml *)
let () =
  print_endline "Hi there"
