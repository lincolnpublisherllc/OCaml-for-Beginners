print_endline "A?"; let a = read_line () |> float_of_string in
        print_endline "B?"; let b = read_line () |> float_of_string in
        Printf.printf "Result: %.2f\n" (compute op a b);
