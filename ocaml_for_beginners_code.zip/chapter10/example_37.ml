type op = Add | Sub | Mul | Div | Unknown
