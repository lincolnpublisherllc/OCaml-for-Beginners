let only_done tasks = List.filter (fun t -> t.done_) tasks
let only_todo tasks = List.filter (fun t -> not t.done_) tasks
