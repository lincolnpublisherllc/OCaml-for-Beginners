type cmd =
