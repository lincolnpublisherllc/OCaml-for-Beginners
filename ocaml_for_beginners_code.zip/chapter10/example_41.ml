let cmd = read_line () |> String.trim in
    if cmd = "quit" then print_endline "Bye."
