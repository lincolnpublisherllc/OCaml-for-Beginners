let read_int_opt () =
  match int_of_string_opt (read_line_trim ()) with
