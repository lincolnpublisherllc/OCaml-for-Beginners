let save (filename : string) (tasks : model) : unit =
  let oc = open_out filename in
  List.iter
