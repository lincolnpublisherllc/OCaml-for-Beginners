let rec main_loop (tasks : model) : unit =
  print_endline "";
  print_endline "Commands: add | list | toggle | delete | quit";
