let parse_cmd (s : string) : cmd =
  match String.lowercase_ascii (String.trim s) with
