let prompt s =
