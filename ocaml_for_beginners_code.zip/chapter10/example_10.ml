let add_task (title : string) (tasks : model) : model =
  let t = make_task title in
