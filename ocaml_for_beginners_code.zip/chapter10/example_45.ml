let rename_task id new_title tasks =
  List.map (fun t -> if t.id = id then { t with title = new_title } else t) tasks
