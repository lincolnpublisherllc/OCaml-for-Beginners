let tasks' = delete_task id tasks in
          print_endline "Deleted (if present).";
