let read_line_trim () =
  let s = read_line () in
  String.trim s
