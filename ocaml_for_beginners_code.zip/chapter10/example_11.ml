let toggle_task (id : int) (tasks : model) : model =
  List.map
