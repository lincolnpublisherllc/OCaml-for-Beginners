let load (filename : string) : model =
  if not (Sys.file_exists filename) then [] else
  let ic = open_in filename in
  let rec loop acc =
    match input_line ic |> Option.some with
