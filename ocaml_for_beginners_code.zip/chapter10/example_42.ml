let op = parse_op cmd in
      if op = Unknown then (print_endline "Unknown op"; loop ())
