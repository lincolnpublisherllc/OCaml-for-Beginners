let () =
  print_endline "Calculator (add|sub|mul|div or quit)";
  let rec loop () =
