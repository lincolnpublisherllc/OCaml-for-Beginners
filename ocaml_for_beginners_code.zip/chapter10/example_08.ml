let render_task (t : task) : string =
  let box = if t.done_ then "x" else " " in
