let tasks' = toggle_task id tasks in
          print_endline "Toggled (if present).";
