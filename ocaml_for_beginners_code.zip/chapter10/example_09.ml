let render_list (tasks : model) : string =
  match tasks with
