let title = read_line_trim () in
      let tasks' = add_task title tasks in
      print_endline "Added.";
