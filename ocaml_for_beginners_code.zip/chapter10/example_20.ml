match parse_cmd (read_line_trim ()) with
