let parse_op s =
  match String.lowercase_ascii (String.trim s) with
