let compute op a b =
  match op with
