done_ : bool;  (* trailing underscore to avoid keyword clash *)
