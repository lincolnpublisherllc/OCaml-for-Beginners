match String.split_on_char '\t' line with
