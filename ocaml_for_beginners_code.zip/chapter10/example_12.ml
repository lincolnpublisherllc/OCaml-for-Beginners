let delete_task (id : int) (tasks : model) : model =
  List.filter (fun t -> t.id <> id) tasks
