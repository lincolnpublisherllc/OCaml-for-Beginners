for loop
(* sum_for.ml *)
let () =
  let total = ref 0 in
  for i = 1 to 5 do
