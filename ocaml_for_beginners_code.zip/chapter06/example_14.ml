let () =
  Printf.printf "%s\n" (classify 3 4 5);  (* scalene *)
  Printf.printf "%s\n" (classify 2 2 3);  (* isosceles *)
  Printf.printf "%s\n" (classify 4 4 4)   (* equilateral *)
