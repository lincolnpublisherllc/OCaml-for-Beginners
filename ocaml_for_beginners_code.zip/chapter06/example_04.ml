let () =
  print_endline (greet (Some "Ada"));
  print_endline (greet None)
