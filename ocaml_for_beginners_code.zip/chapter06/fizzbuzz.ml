(* fizzbuzz.ml *)
let label n =
  match (n mod 3 = 0, n mod 5 = 0) with
