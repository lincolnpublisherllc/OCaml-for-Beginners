(* cmd.ml *)
let handle_cmd cmd =
  match String.lowercase_ascii cmd with
