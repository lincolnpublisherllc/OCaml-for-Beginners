if returns a value and both branches must share a type.
