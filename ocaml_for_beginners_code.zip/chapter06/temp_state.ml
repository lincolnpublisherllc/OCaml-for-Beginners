(* temp_state.ml *)
let state c =
  if c <= 0 then "freezing"
