(* echo_until_empty.ml *)
let () =
  print_endline "Type lines. Empty line to stop.";
  let line = ref "" in
  while (print_string "> "; flush stdout; line := read_line (); String.length !line > 0) do
    print_endline ("You said: " ^ !line)
