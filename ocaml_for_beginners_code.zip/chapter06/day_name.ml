(* day_name.ml *)
let day_name n =
  match n with
