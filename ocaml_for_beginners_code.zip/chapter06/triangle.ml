(* triangle.ml *)
let classify a b c =
  if a + b <= c || a + c <= b || b + c <= a then "not a triangle"
