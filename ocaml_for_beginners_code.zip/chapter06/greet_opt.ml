(* greet_opt.ml *)
let greet maybe_name =
  match maybe_name with
