(* sign.ml *)
let sign n =
  if n > 0 then "positive"
