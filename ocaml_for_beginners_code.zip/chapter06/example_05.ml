let () =
  Printf.printf "%d\n" (first_or_default [10; 20]);
  Printf.printf "%d\n" (first_or_default [])
