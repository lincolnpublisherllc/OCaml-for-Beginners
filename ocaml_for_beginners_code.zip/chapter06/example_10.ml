let () =
  Printf.printf "%b\n" (can_access 19 true);   (* true *)
  Printf.printf "%b\n" (can_access 19 false);  (* false *)
  Printf.printf "%b\n" (can_access 21 false)   (* true *)
