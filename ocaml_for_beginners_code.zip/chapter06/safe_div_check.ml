(* safe_div_check.ml *)
let safe_div a b =
  if b <> 0 && a mod b = 0 then true else false
