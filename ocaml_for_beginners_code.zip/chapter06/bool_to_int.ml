(* bool_to_int.ml *)
let bool_to_int b =
  match b with
