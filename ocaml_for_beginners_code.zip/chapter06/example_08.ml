for i = 10 downto 1 do
  Printf.printf "%d " i
