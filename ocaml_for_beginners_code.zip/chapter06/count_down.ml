while loop
(* count_down.ml *)
let () =
  let n = ref 5 in
  while !n > 0 do
    Printf.printf "%d\n" !n;
