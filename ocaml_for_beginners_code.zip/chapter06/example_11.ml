let () =
  for i = 1 to 16 do
    print_endline (label i)
