(* first_or_default.ml *)
let first_or_default lst =
  match lst with
