match (a = b, b = c, a = c) with
