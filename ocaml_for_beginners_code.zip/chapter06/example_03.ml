let () = print_endline (day_name 6)
