let max2 a b = if a >= b then a else b
