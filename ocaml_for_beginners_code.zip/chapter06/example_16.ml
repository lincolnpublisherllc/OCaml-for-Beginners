while and for loops are fine for small tasks that work step by step.
