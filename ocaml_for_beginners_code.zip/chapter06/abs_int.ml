(* abs_int.ml *)
let abs_int n = if n < 0 then -n else n
