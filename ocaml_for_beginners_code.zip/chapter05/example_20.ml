let percent part whole =
