let avg_int a b = (a + b) / 2    (* drops the .5 if sum is odd *)
