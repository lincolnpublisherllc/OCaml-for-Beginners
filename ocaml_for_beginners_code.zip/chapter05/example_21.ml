let () =
  Printf.printf "%.2f\n" (weighted_avg 80.0 0.6 50.0 0.4)
