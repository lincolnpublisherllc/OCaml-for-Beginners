let mean a b = (a +. b) /. 2.0
