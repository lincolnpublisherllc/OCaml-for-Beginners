let () =
  print_endline "Score?";
  let s = int_of_string (read_line ()) in
  Printf.printf "Grade: %c\n" (letter s)
