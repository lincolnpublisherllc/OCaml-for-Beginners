let percent part whole =
  (* wrong: if part and whole are int, this is integer division *)
