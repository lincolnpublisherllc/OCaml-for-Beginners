(* bmi.ml *)
let bmi kg m = kg /. (m *. m)
