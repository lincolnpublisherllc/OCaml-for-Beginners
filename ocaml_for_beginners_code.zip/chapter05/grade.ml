(* grade.ml *)
let letter score =
  if score >= 70 then 'A'
