(* summary.ml *)
let summarize name count price =
  let total = float_of_int count *. price in
