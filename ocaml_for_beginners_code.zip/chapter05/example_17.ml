let density mass volume =
  float_of_int mass /. volume   (* if mass is int and volume is float *)
