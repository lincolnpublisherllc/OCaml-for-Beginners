let add a b =
  let s = a + b in    (* s is a value *)
