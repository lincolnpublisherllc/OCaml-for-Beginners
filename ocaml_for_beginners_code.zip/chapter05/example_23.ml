let () =
  print_endline (summarize "pen" 3 120.5)
