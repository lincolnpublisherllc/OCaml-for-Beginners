if returns the chosen value.
