let avg a b = (float_of_int (a + b)) /. 2.0
