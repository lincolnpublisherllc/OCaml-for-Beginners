let () =
  print_endline "Enter three integers:";
  let a = int_of_string (read_line ()) in
  let b = int_of_string (read_line ()) in
  let c = int_of_string (read_line ()) in
  Printf.printf "min = %d\n" (min3 a b c)
