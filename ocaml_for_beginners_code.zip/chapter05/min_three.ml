(* min_three.ml *)
let min2 a b = if a < b then a else b
