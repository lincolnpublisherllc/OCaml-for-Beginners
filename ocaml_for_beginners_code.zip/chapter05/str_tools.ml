(* str_tools.ml *)
let () =
  print_endline "Say something:";
  let s = read_line () in
  let len = String.length s in
  let loud = String.uppercase_ascii s in
  let echoed = s ^ " | " ^ loud in
  Printf.printf "len=%d\n%s\n" len echoed
