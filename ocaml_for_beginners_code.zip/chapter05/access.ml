(* access.ml *)
let can_access age has_id =
