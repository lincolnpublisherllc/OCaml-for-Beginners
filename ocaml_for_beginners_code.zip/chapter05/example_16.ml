let avg a b = (float_of_int a +. float_of_int b) /. 2.0
