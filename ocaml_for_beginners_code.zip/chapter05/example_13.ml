let () =
  print_endline "Weight in kg?";
  let kg = float_of_string (read_line ()) in
  print_endline "Height in meters?";
  let m = float_of_string (read_line ()) in
  let b = bmi kg m in
  Printf.printf "BMI = %.1f (%s)\n" b (classify b)
