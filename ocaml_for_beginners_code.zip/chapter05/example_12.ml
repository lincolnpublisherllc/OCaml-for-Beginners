let classify x =
  if x < 18.5 then "underweight"
