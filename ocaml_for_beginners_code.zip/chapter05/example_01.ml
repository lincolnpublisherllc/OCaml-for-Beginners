let () =
  let a, b = 7, 2 in
  Printf.printf "int: %d + %d = %d\n" a b (a + b);
  Printf.printf "int div: %d / %d = %d\n" a b (a / b);
  Printf.printf "float: %.1f /. %.1f = %.1f\n" 7.0 2.0 (7.0 /. 2.0);
  Printf.printf "cmp: %b %b %b\n" (a = b) (a > b) (a <> b);
  Printf.printf "bool: %b\n" ((a > 0) && (b > 0));
  Printf.printf "concat: %s\n" ("OC" ^ "aml")
