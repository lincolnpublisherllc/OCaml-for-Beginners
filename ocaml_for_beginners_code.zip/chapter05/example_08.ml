let min3 a b c = min2 (min2 a b) c
