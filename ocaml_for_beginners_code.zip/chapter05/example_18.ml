Printf.printf "x=%.1f\n" 3.0;   (* ok *)
Printf.printf "x=%d\n" 3;       (* ok *)
(* Printf.printf "x=%.1f\n" 3;;  (* error: 3 is int, %.1f expects float *) *)
