let () =
  print_endline "one";
  print_endline "two"  (* value of the whole block is unit *)
