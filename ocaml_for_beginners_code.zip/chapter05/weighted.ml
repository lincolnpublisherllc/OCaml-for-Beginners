(* weighted.ml *)
let weighted_avg x wx y wy =
