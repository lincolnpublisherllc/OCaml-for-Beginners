let head_or_zero lst =
  match lst with
