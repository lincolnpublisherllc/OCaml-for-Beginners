let () =
  let tbl = word_counts ["a";"b";"a";"a";"b"] in
