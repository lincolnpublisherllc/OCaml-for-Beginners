let normalize_name s =
  let s = String.trim s in
  String.capitalize_ascii (String.lowercase_ascii s)
