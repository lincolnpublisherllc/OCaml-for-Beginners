let a = [|10; 20; 30|]
let () =
  Printf.printf "len=%d first=%d\n" (Array.length a) a.(0)
