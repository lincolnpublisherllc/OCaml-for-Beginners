let rec sum lst =
  match lst with
