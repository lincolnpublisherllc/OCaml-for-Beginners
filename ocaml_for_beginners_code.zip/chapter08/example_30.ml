let running_averages (a : float array) : float array =
  let n = Array.length a in
  let out = Array.make n 0.0 in
  let sum = ref 0.0 in
  for i = 0 to n - 1 do
