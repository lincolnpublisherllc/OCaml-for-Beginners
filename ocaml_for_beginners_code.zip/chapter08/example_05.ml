let doubled = List.map (fun x -> x * 2) [1;2;3]      (* [2;4;6] *)
let evens   = List.filter (fun x -> x mod 2 = 0) [1;2;3;4]  (* [2;4] *)
