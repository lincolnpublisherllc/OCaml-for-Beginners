let revd = List.rev [1;2;3]                (* [3;2;1] *)
let sorted = List.sort compare [3;1;4;2]   (* [1;2;3;4] *)
