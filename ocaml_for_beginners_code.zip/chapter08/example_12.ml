let zeros = Array.make 5 0               (* [|0;0;0;0;0|] *)
let squares = Array.init 5 (fun i -> i*i)  (* [|0;1;4;9;16|] *)
