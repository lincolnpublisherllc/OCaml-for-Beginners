List.nth is O(n). If you need frequent random access, use an array.
