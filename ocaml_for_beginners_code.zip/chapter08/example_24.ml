let sum' lst = List.fold_left (fun acc x -> acc + x) 0 lst
