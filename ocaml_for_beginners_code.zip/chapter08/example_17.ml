let () =
  H.add counts "pen" 3;       (* add fails if key exists; use replace to overwrite *)
  H.replace counts "pen" 4;   (* sets or overwrites *)
