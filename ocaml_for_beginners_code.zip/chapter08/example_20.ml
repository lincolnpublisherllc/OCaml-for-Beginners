let word_counts (ws : string list) : (string, int) H.t =
  let tbl = H.create 32 in
  List.iter
