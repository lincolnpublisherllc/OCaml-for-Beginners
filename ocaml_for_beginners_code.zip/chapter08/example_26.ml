let inc_all a =
  for i = 0 to Array.length a - 1 do
