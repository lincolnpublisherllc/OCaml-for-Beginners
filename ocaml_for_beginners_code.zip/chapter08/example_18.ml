match H.find_opt counts "pen" with
