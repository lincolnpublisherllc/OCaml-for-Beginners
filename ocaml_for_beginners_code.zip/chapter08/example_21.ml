let n = match H.find_opt tbl w with Some x -> x | None -> 0 in
