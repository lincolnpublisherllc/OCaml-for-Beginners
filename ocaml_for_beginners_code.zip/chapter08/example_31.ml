let () =
  let r = running_averages [|10.0; 20.0; 30.0|] in
  Array.iter (Printf.printf "%.1f ") r; print_endline ""
