let () =
  Printf.printf "length=%d\n" (List.length numbers);
  Printf.printf "first=%d\n" (List.hd numbers);
  Printf.printf "second=%d\n" (List.nth numbers 1)
