Array.iter (fun x -> Printf.printf "%d " x) squares; print_endline "";
let doubled = Array.map (fun x -> x * 2) squares;
