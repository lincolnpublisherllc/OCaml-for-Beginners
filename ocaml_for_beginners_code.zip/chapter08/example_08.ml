let rec last lst =
  match lst with
