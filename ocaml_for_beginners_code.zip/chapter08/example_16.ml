let counts : (string, int) H.t = H.create 16   (* initial bucket count *)
