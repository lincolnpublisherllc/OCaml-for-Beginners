List.iter (fun s -> print_endline s) ["a";"b";"c"]
