if H.mem counts "book" then H.remove counts "book";
