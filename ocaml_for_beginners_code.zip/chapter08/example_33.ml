let frequencies (xs : string list) : (string, int) H.t =
  let t = H.create 32 in
  List.iter (fun k ->
