let () =
  let raw = ["  ADA"; "  lovelace "; "ocaml"] in
  let clean = List.map normalize_name raw in
  List.iter print_endline clean
