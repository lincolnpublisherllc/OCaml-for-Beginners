let doubled = Array.map (fun x -> x * 2) [|1;2;3|]
