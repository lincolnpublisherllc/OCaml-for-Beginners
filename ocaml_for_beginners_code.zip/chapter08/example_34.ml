let () =
  let t = frequencies ["red";"blue";"red";"green";"red"] in
