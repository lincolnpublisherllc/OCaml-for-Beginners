(* Sum with fold_left: accumulator flows left to right *)
let sum = List.fold_left (fun acc x -> acc + x) 0 [1;2;3;4]  (* 10 *)
