let arr = [|1;2;3|] in
let lst = Array.to_list arr in
let back = Array.of_list lst
