let () = ... defines the program’s entry point in a simple way.
print_endline writes a line of text to the console.
