(* sum_to n returns 1 + 2 + ... + n *)
let rec sum_to n =
  if n <= 0 then 0
