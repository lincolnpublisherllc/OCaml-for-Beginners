(* hello.ml: a first OCaml program *)
let () =
  print_endline "Hello, OCaml beginner!";
  print_endline "You just ran your first program."
