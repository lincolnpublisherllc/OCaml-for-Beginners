(* compute.ml *)
let () =
  let a = 8 in
  let b = 3 in
  let sum = a + b in
  let diff = a - b in
  let prod = a * b in
  let quot = float_of_int a /. float_of_int b in
  (* Printf.printf formats numbers and strings *)
  Printf.printf "sum=%d diff=%d prod=%d quot=%.2f\n" sum diff prod quot
