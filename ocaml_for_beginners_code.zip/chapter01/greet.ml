(* greet.ml *)
let greet name =
