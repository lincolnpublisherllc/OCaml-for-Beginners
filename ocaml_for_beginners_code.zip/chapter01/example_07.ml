# let square x = x * x;;
val square : int -> int = <fun>
