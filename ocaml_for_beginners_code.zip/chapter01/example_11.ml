let () =
  Printf.printf "square 4 = %d\n" (square 4);
  Printf.printf "square 9 = %d\n" (square 9)
