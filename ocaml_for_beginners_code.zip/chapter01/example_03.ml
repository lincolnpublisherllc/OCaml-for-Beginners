let () =
  let n = 5 in
  let total = ref 0 in         (* ref creates a mutable integer cell *)
  for i = 1 to n do
    total := !total + i        (* ! reads, := writes *)
