Printf.printf "Sum to %d = %d\n" n !total
