let () =
  let result = sum_to 5 in
  Printf.printf "Sum to 5 = %d\n" result
