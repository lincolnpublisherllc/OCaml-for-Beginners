(* square.ml *)
let square x = x * x
