(* refs.ml *)
let () =
  let counter = ref 0 in
