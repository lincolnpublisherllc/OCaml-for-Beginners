(* conversions.ml *)
let () =
  let apples = 7 in
  let boxes = 2 in
  let avg = float_of_int apples /. float_of_int boxes in
  Printf.printf "Average per box: %.2f\n" avg
