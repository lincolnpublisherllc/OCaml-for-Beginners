let () =
  let c = 25.0 in
  let f = c_to_f c in
  Printf.printf "%.1f C = %.1f F\n" c f
