let () =
  let r = say_hello () in  (* r has type unit *)
  match r with
