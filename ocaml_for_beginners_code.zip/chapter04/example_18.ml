let close_enough a b =
  let eps = 1e-9 in
