Printf.printf "value=%d\n" 3;
Printf.printf "value=%.1f\n" 3.0
