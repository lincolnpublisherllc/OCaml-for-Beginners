(* immutables.ml *)
let () =
  let x = 5 in
  (* x stays 5 for its whole lifetime *)
  Printf.printf "x = %d\n" x
