Printf.printf "sum 1..5 = %d\n" !total
