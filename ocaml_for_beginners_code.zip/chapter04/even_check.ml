(* even_check.ml *)
let is_even n = n mod 2 = 0
