let add a b = a + b
(* Inferred: add : int -> int -> int *)
