let () =
  let n = 14 in
  Printf.printf "%d even? %b\n" n (is_even n)
