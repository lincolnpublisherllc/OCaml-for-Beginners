(* temp.ml *)
let c_to_f c =
