(* Printf.printf "value=%f\n" 3;;  (* type error: 3 is int, %f expects float *) *)
