let average a b =
  (a + b) / 2           (* int average, truncates *)
let average_float a b =
  (a +. b) /. 2.0       (* float average *)
