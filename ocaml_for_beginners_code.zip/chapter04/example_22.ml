(* int_of_string "abc"  (* raises Failure "int_of_string" *) *)
