let () =
  let x = 5 in
  let x = x + 1 in     (* new x shadows the old x *)
  Printf.printf "x = %d\n" x   (* prints 6 *)
