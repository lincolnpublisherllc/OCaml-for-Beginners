let add_int (a : int) (b : int) : int = a + b
