Printf.printf "counter = %d\n" !counter
