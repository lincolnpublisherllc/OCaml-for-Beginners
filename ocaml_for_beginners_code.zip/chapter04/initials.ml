(* initials.ml *)
let () =
  print_endline "First name:";
  let f = read_line () in
  print_endline "Last name:";
  let l = read_line () in
  let initial s = s.[0] in
  Printf.printf "Initials: %c.%c.\n" (initial f) (initial l)
