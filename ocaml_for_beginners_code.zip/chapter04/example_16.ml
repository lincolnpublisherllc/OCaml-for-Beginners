let () =
  let cost = 12999 in
  let cost_f = float_of_int cost /. 100.0 in
  Printf.printf "Cost: %d kobo (₦%.2f)\n" cost cost_f
