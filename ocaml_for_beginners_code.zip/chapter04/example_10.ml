let () =
  Printf.printf "int: %d\n" (3 + 4);
  Printf.printf "float: %.2f\n" (3.0 +. 4.5);
  Printf.printf "concat: %s\n" ("OC" ^ "aml")
