let ratio a b =
  (* a and b inferred as int because of + and *? Not here. We choose floats to be clear. *)
