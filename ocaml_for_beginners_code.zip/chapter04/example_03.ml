!r reads the value.
