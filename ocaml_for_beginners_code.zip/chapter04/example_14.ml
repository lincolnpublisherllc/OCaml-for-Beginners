(* To compile, a and b must be float, or you must convert. *)
