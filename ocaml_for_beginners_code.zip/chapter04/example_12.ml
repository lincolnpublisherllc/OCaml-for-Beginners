let greet name = "Hello, " ^ name
(* Inferred: greet : string -> string *)
