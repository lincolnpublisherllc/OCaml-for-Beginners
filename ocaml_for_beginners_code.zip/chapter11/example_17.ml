let last a =
  let n = Array.length a in
  if n = 0 then None else Some a.(n - 1)
