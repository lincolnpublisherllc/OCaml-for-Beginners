match lst with
