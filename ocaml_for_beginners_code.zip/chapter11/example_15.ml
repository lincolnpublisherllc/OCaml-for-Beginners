(* Bad: O(n^2) pattern *)
let bad_build n =
  let rec go i acc =
    if i > n then acc else go (i+1) (acc @ [i])  (* slow *)
