Printf.printf "[debug] i=%d of %d\n" i (Array.length a - 1)
