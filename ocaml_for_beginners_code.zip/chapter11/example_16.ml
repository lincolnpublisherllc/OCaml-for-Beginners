(* Good: build with :: then reverse once *)
let good_build n =
  let rec go i acc =
    if i > n then List.rev acc else go (i+1) (i :: acc)
