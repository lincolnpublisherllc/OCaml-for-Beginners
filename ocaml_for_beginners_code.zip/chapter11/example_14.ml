let divides a b =
  b <> 0 && a mod b = 0   (* a mod b is not evaluated if b = 0 *)
