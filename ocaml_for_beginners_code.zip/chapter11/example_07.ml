let sum_list = List.fold_left ( + ) 0
