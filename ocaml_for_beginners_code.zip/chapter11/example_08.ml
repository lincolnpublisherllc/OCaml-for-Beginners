let average_int a b = (a + b) / 2          (* truncates *)
let average a b = (float_of_int a +. float_of_int b) /. 2.0
Printf.printf "total=%.2f\n" 3.0;  (* ok *)
(* Printf.printf "total=%.2f\n" 3;;  (* WRONG: 3 is int *) *)
