(* bad_format.ml *)
let () =
  let n = 3 in
  Printf.printf "n=%.1f\n" n   (* %f expects float, but n is int *)
