(* OK when needed: small, local mutation *)
let sum_array a =
  let total = ref 0 in
  for i = 0 to Array.length a - 1 do
