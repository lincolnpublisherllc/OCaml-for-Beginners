let format_line item price qty =
