(* Warning: this pattern-matching is not exhaustive. *)
