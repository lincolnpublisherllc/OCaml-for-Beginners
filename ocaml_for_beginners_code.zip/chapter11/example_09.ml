(* Good: no mutation *)
let sum_list = List.fold_left ( + ) 0
