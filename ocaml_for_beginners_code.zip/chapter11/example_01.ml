let () =
  let n = 3 in
  Printf.printf "n=%d\n" n
(* or: Printf.printf "n=%.1f\n" (float_of_int n) *)
